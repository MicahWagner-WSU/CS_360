to compile, run "make" in the command line while in this assignmnts directory
then type "./pairsofwords <-count> <file1> <file2> <file...>" 
-count is going to print the top pairsofwords up until count
you can input an arbitrary amount of files into ./pairsofwords